
    // OPTIMIZED SCALING WITH DEBOUNCING - FROM INDEX2.HTML
    let resizeTimeout;

    function scaleToFit() {
      const container = document.querySelector('.main-sec');
      const viewportWidth = window.innerWidth;
      const designWidth = 1920;

      if (container && viewportWidth < designWidth) {
        const scale = viewportWidth / designWidth;

        if (navigator.userAgent.indexOf('Firefox') > -1) {
          container.style.transform = `scale(${scale})`;
          container.style.transformOrigin = 'top left';
        } else {
          container.style.zoom = scale;
        }

        document.body.style.width = `${viewportWidth}px`;
        document.body.style.overflowX = 'hidden';
      } else if (container) {
        container.style.transform = '';
        container.style.zoom = '';
        document.body.style.width = '';
        document.body.style.overflowX = '';
      }
    }

    // Debounced resize handler for better performance
    function handleResize() {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(scaleToFit, 100);
    }

    window.addEventListener('load', scaleToFit);
    window.addEventListener('resize', handleResize, { passive: true });
